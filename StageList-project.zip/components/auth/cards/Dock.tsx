import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';
import { faSpotify } from '@fortawesome/free-brands-svg-icons';
import { DockProps } from '@/components/auth/cards/types';
export default function Dock({ dock, setDock }: DockProps) {

  return (
    <>
      <div className="relative dock dock-md sm:hidden">
        <button className={`${dock === 'left' ? 'dock-active' : ''}`} onClick={() => setDock('left')}>
          <FontAwesomeIcon icon={faUser} />
          <span className="dock-label">Login</span>
        </button>

        <button className={`${dock === 'right' ? 'dock-active' : ''}`} onClick={() => setDock('right')}>
          <FontAwesomeIcon icon={faSpotify} />
          <span className="dock-label">Spotify Login</span>
        </button>
      </div>
    </>
  );
}